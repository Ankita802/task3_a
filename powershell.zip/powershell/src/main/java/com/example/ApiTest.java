import io.rest-assured.RestAssured;
import io.rest-assured.response.Response;
import io.rest-assured.specification.RequestSpecification;
import static io.rest-assured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;
import static org.hamcrest.Matchers.equalTo;

public class ApiTest {

        private static final String BASE_URL = "http://your-api-url.com/api"; // replace with actual API URL

        public static void main(String[] args) {
                RestAssured.baseURI = BASE_URL;

                RequestSpecification requestSpecification = RestAssured.given();

                // Set request content type
                requestSpecification.contentType("application/json");

                // Create JSON body for the POST request
                String reqBody = "{\n" +
                                "  \"name\": \"joe\",\n" +
                                "  \"gender\": \"male\",\n" +
                                "  \"email\": \"joeyUNIQUE@townsqd.com\",\n" +
                                "  \"status\": \"active\"\n" +
                                "}";

                // POST request to create a new user
                Response response = requestSpecification.body(reqBody)
                                .post("/users"); // replace "/users" with actual path if different

                // Validate schema
                response.then().assertThat().body(matchesJsonSchemaInClasspath("user-schema.json"));

                // Validate status code and content
                response.then().assertThat()
                                .statusCode(200)
                                .body("name", equalTo("joe"))
                                .body("gender", equalTo("male"))
                                .body("email", equalTo("joeyUNIQUE@townsqd.com"))
                                .body("status", equalTo("active"));

                System.out.println("Response body:\n" + response.body().prettyPrint());
        }
}
