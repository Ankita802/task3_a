
# Read content from rpaChallengeFeature.txt file
$featureFilePath = "C:\Users\Hp\Desktop\powershell\src\resources\features\TestCase1.txt"

# Set Code file path
$CodefilePath = "C:\Users\Hp\Desktop\powershell\src\main\java\com\example\GeneratedAICode.java"


$featureContent = Get-Content -Path $featureFilePath -Raw

# Set API endpoint
$endpoint = "https://api.openai.com/v1/chat/completions"

# Set headers
$headers = @{
    "Content-Type" = "application/json"
    "Accept" = "application/json"
    "Authorization" = "Bearer sk-proj-6LcuZ74IPJXwKuAoT5jrT3BlbkFJb11dG1MbhpIMcARM45W6"
    "Cookie" = "__cf_bm=EJBUBMe_o31PeVThk.9ywwWLRkamx9A9pT4jAxjXW4M-1715917815-1.0.1.1-PW2WyDdtyUqHDv6oflUkIFj.NgOhFHKPgiuigJjn1UdDAacluuoYn0tzF5qa9ephpjGn.N0.UJUAOV4Sho91xQ; _cfuvid=pP3rRUKdN0MvEt9GlNi3j9OMPaEw_RwlPKEXxn5PfE0-1715914702942-0.0.1.1-604800000"
}

# Set data
$data = @{
    "model" = "gpt-4-turbo"
    "messages" = @(
        @{
            "role" = "user"
            "content" = "Give selenium and java code for below scenario.$featureContent"
        }
    )
    "temperature" = 1
    "top_p" = 1
    "n" = 1
    "stream" = $false
    "max_tokens" = 4096
    "presence_penalty" = 0
    "frequency_penalty" = 0
}

# Convert data to JSON
$jsonData = $data | ConvertTo-Json

# Send request
$response = Invoke-RestMethod -Uri $endpoint -Method Post -Headers $headers -Body $jsonData

# Check if response is empty
if (-not $response) {
    Write-Output "Error: Empty response received."
    exit
}

# Extract Java code from the response
$javaCode = $response.choices[0].message.content

# Find the index of the first "import" statement
$importIndex = $javaCode.IndexOf("import")

# Find the index of the last "}" symbol
$lastBraceIndex = $javaCode.LastIndexOf("}")

# Remove any text before "import" and after the last "}"
if ($importIndex -ge 0 -and $lastBraceIndex -ge 0) {
    $javaCode = $javaCode.Substring($importIndex, $lastBraceIndex - $importIndex + 1)
}

# Set Code file path
$CodefilePath = "C:\Users\Hp\Desktop\powershell\src\main\java\com\example\GeneratedAICode.java"

# Write Java code to file
$javaCode | Set-Content -Path $CodefilePath -Force

Write-Output "Java code written to $filePath"
