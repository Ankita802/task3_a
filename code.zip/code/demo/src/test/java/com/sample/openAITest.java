// package com.sample;

// import static org.junit.Assert.assertTrue;

// import org.junit.Test;

// /**
//  * Unit test for simple App.
//  */
// public class openAITest {
//     /**
//      * Rigorous Test :-)
//      */
//     @Test
//     public void shouldAnswerWithTrue() {
//         assertTrue(true);
//     }
// }

package com.sample;

// import static org.junit.Assert.assertTrue;
import org.junit.Test;

import io.restassured.RestAssured;

// import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.*;
import static io.restassured.module.jsv.JsonSchemaValidator.*;

public class openAITest {

    @Test
    public void testCreateUserWithValidData() {
        String requestBody = "{" +
                "\"name\": \"joe\"," +
                "\"gender\": \"male\"," +
                "\"email\": \"joeyUNIQUE@townsqd.com\"," +
                "\"status\": \"active\"" +
                "}";

        RestAssured.given().contentType("application/json").body(requestBody).when()
                .post("https://your-api-url.com/users"). // Replace
                // with
                // your
                // actual
                // API
                // endpoint
                then().assertThat().statusCode(200)
                .body(matchesJsonSchemaInClasspath("user-schema.json"))
                .body("name", equalTo("joe")).body("gender", equalTo("male"))
                .body("email", equalTo("joeyUNIQUE@townsqd.com")). // Corrected field name
                body("status", equalTo("active"));
    }
}
