package com.sample;

import java.io.IOException;
import java.nio.file.Files;
// import java.nio.file.Path;
import java.nio.file.Paths;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;

public class openAI {

    private static final String FEATURE_FILE_PATH = "C:\\Users\\Hp\\Desktop\\TX\\TestCase1.txt";
    private static final String CODE_FILE_PATH = "C:\\Users\\Hp\\Desktop\\TX\\TestCase.java";
    private static final String API_ENDPOINT = "https://api.openai.com/v1/chat/completions";
    private static final String API_KEY = "Bearer sk-proj-6LcuZ74IPJXwKuAoT5jrT3BlbkFJb11dG1MbhpIMcARM45W6";

    public static void main(String[] args) {
        try {
            // Read feature file content
            String featureContent = Files.readString(Paths.get(FEATURE_FILE_PATH));

            // Create JSON payload
            ObjectMapper objectMapper = new ObjectMapper();
            ObjectNode data = objectMapper.createObjectNode();
            data.put("model", "gpt-4-turbo");

            ArrayNode messages = objectMapper.createArrayNode();
            ObjectNode message = objectMapper.createObjectNode();
            message.put("role", "user");
            message.put("content", "Give selenium and java code for below scenario." + featureContent);
            messages.add(message);

            data.set("messages", messages);
            data.put("temperature", 1);
            data.put("top_p", 1);
            data.put("n", 1);
            data.put("stream", false);
            data.put("max_tokens", 4096);
            data.put("presence_penalty", 0);
            data.put("frequency_penalty", 0);

            String jsonData = data.toString();

            // Create HTTP client and request
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(API_ENDPOINT))
                    .header("Content-Type", "application/json")
                    .header("Accept", "application/json")
                    .header("Authorization", API_KEY)
                    .POST(HttpRequest.BodyPublishers.ofString(jsonData))
                    .build();

            // Send request and get response
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() != 200) {
                System.out.println("Error: " + response.body());
                return;
            }

            // Parse response
            JsonNode responseJson = objectMapper.readTree(response.body());
            String javaCode = responseJson.path("choices").get(0).path("message").path("content").asText();

            // Process Java code
            int importIndex = javaCode.indexOf("import");
            int lastBraceIndex = javaCode.lastIndexOf("}");

            if (importIndex >= 0 && lastBraceIndex >= 0) {
                javaCode = javaCode.substring(importIndex, lastBraceIndex + 1);
            }

            // Write Java code to file
            Files.writeString(Paths.get(CODE_FILE_PATH), javaCode);
            System.out.println("Java code written to " + CODE_FILE_PATH);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
}
